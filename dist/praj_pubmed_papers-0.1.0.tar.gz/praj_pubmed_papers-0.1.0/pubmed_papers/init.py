"""
pubmed_papers - A tool to fetch research papers from PubMed with pharmaceutical/biotech affiliations.
"""

__version__ = "0.1.0"
